import java.io.IOException;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;
import java.io.File;  
import java.io.IOException;  
import java.sql.Timestamp;  
import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  
import org.jsoup.nodes.Element; 
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import org.jsoup.select.Elements;
import java.util.regex.*;
public class Climb_web2014302580186 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		String urlname = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Li%20_%20Zhen";
		String file = "C:\\Users\\WXD\\Desktop\\WXD.txt";
		URL path = new URL(urlname);
		FileOutputStream out = new FileOutputStream(file);
		HttpRequest a = new HttpRequest(path,"GET");
	    a.receive(out);
	    out.close();
	    
	    JsoupTry("C:\\Users\\WXD\\Desktop\\WXD.txt","output.txt");
	}
	    
	    
	    
/*	    //jsoup�������
	    String threadUrl1="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Li%20_%20Zhen";
	    Document doc=(Document)Jsoup.connect(threadUrl1).get();
	    System.out.println(doc);}*/
	    
	    //����
	    public static void JsoupTry(String htmlName,String txtName) throws IOException{

	        //��������ļ�
	        File output = new File(txtName);
	        FileWriter fw = new FileWriter(output);
	        BufferedWriter bufw = new BufferedWriter(fw);

	        //���ļ��м���html�ĵ�
	        File input = new File(htmlName);
	        Document doc = Jsoup.parse(input,"UTF-8");

	        //��������ȡHTMLԪ��
	        //��ȡ���ֲ�����
	        Element name = doc.select("h1").get(0);
	        bufw.write("������");
	        bufw.write(name.text());
	        bufw.newLine();

	        //��ȡ��鲢����
	        Elements contents = doc.select("p");
	        bufw.write("��飺");
	        bufw.write(contents.get(3).text());
	        bufw.newLine();

	        
	        //��ȡ�о���������
	       // Element researchDirection = doc.select("p:contains(�о���Ȥ)").get(0);
	        //System.out.println(contents.get(3).text());
	        //bufw.write(contents.get(1).text());

	        Pattern a = Pattern.compile("[0-9]+.+[0-9]");
	        Matcher teacherInfo = a.matcher(contents.get(0).text());
	        while(teacherInfo.find())
	        {
	        	String tmp = teacherInfo.group();
	        	bufw.write("�绰��"+tmp+"\r\n");
	        }
	        a = Pattern.compile("Email+.+\\w");
	        Matcher email = a.matcher(contents.get(0).text());
	        while(email.find())
	        {
	        	String tmp = email.group();
	        	//System.out.print(tmp);
	        	bufw.write(tmp+"\r\n");
	        }
	        a = Pattern.compile("�о�����+.+[\u4E00-\u9FA5]+\\s");
	        Matcher study = a.matcher(contents.get(0).text());
	        while(study.find())
	        	{
	        	String c = study.group();
	        	bufw.write(c);
	        	}
	        //bufw.write(study.group());
	        
	        bufw.close();
	        fw.close();
	    
	    
	}

}